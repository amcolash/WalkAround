# WalkAround
A lightweight chrome extension that reminds you to walk around if you have been sitting (using google fit activity api).
